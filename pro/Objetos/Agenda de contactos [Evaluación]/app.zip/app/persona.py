class Persona():
    def __init__(self,nombre,primer_apellido,segundo_apellido,nif,edad):
        self.nombre = nombre
        self.primer_apellido = primer_apellido
        self.segundo_apellido = segundo_apellido
        self.nif = nif
        self.edad = edad
        