


//Recoje todos los elementos inputs
const inputNombre = document.getElementById('nombreFormulario');
const inputNumero = document.getElementById('numeroFormulario');
const inputFecha = document.getElementById('fechaFormulario');
const inputCvc = document.getElementById('cvcFormulario');
//Recoje todos los elementos de la tarjeta
const tarjetaNombre = document.getElementById('nombreTarjeta');
const tarjetaNumero = document.getElementById('numeroTarjeta');
const tarjetaFecha = document.getElementById('fechaTarjeta');
const tarjetaCvc = document.getElementById('cvcTarjeta');


//console.log(tarjetaNombre.inne);

const maskDate = {
    mask: Date,
    pattern: "m{/}Y0",
    blocks: {
      Y: {
        mask: IMask.MaskedRange,
        placeholderChar: "Y",
        from: 24,
        to: 99,
        maxLength: 2,
      },
    },
  };

const maskCardNumber = {
  mask: "0000 0000 0000 0000",
};

const maskCvc = {
  mask: "000",
};

IMask(inputFecha, maskDate);
IMask(inputNumero, maskCardNumber);
IMask(inputCvc, maskCvc);


// inputNombre.addEventListener("oninput",actualizaValor(inputNombre,tarjetaNombre))

// function actualizaValor(input,valor) {
//     valor.textContent = input.value;
//     console.log(input.value);
// }


//function showCurrentValue(event){
//    const value = event.target.value;
//    document.getElementById("numeroTarjeta").innerText = value;
//}
//inputNumero.addEventListener("oninput" = edValueKeyPress() ) 
//
//function edValueKeyPress() {
//  var inputNumero = document.getElementById("numeroFormulario");
//  var s = inputNumero.value;
//
//  var numeroTarjeta1 = document.getElementById("numeroTarjeta");
//  numeroTarjeta1.innerText = s;
//}


function anhadirEventos (){
    let inputs = [inputNombre,inputNumero,inputFecha,inputCvc];
    let valores = [tarjetaNombre,tarjetaNumero,tarjetaFecha,tarjetaCvc];

    for (let i = 0; i < inputs.length; i++) {  
        inputs[i].addEventListener("keyup", ()=> {
            valores[i].innerHTML = inputs[i].value;
        });
    }
}



anhadirEventos();
// inputNombre.addEventListener("keyup", ()=> {
//     tarjetaNombre.innerHTML = inputNombre.value;
// });

// inputNumero.addEventListener("keyup", ()=> {
//     tarjetaNombre.innerHTML = inputNombre.value;
// });




// function showCurrentValue(input,valor) {
//   // Obtén el valor del campo de entrada del número de tarjeta
//   const entrada = document.getElementById(input);
//   const contenido = document.getElementById(valor);

//   // Actualiza el contenido del elemento <p> con el valor del campo de entrada
//   contenido.textContent = entrada.value;
// }

// // Llama a la función showCurrentValue() cuando se modifica el campo de entrada
// document.getElementById("numeroFormulario").addEventListener("input", showCurrentValue("numeroFormulario","numeroTarjeta"));
